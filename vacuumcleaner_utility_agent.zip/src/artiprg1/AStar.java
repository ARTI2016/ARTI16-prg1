package artiprg1;

public class AStar {

}
