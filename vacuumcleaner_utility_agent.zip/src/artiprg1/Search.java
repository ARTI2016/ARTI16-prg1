package artiprg1;

public interface Search {
    String nextMove();
}